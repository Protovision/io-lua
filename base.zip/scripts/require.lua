
local function module_loader(module)
	local chunk = LoadData(module .. '.lua')
	return load(chunk, module .. '.lua', 't')()
end

local function package_searcher(module)
	return module_loader, module
end

package.searchers = { package_searcher }


