SetColor(COLOR_YELLOW)
Clear()
SetColor(COLOR_BLACK)
