
cover = LoadImage("tuxedo.jpg")
track = LoadSound("Do it.ogg")
cursor = LoadCursor("cursor.png", 10, 10);

DrawBackground(cover)
SetCursor(cursor);
LoopSound(track)

function keyboard(key, status)
	if status ~= PRESSED then return end
	if key == KEY_F then
		SetFullscreen(true)
	elseif key == KEY_W then
		SetFullscreen(false)
	end
end

function shutdown()
	StopAudio()
	FreeSound(track)
	FreeCursor(cursor)
end

