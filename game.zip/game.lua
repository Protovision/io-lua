
cover = LoadImage("tuxedo.jpg")
track = LoadSound("Do it.ogg")
cursor = LoadCursor("cursor.png", 10, 10);

DrawBackground(cover)
SetCursor(cursor);
channel = LoopSound(track)

function shutdown()
	StopSound(channel)
	FreeSound(track)
	FreeCursor(cursor)
end

