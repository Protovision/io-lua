
cover = LoadImage("tuxedo.jpg")
track = LoadSound("Do it.ogg")

DrawBackground(cover)
LoopSound(track)

function shutdown()
	StopAudio()
	FreeSound(track)
end

