
image = LoadImage("ocean.jpg")
music = LoadSound("Magic.ogg")

DrawBackground(image)
channel = LoopSound(music)

function shutdown()
	FreeImage(image)
	StopSound(channel)
	FreeSound(music)
end
