
x = 0
y = 50 
w, h = GetWindowSize()
SetColor(COLOR_WHITE)

lasttime = 0
function update()
	time = GetTicks()
	if time - lasttime > 10 then 
		if x == w then x = 0 end
		Clear()
		DrawText(x - w, y, "Hello world!")
		DrawText(x, y, "Hello world!")
		x = x + 1 
		lasttime = time
	end
end
