Call("a.lua")
DrawText(0, 0, "Hello world!")
