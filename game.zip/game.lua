
require 'a'
cover = LoadImage("tuxedo.jpg")
track = LoadSound("Do it.ogg")
cursor = LoadCursor("cursor.png", 10, 10);

DrawBackground(cover)
SetCursor(cursor);
LoopSound(track)

function shutdown()
	StopSound(track)
	FreeSound(track)
	FreeCursor(cursor)
end

