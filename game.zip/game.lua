
SetColor(COLOR_BLACK)
Clear()
DrawText(10, 10, "Hello", COLOR_BLUE)
